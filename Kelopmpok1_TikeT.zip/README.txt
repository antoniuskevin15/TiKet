Nama anggota kelompok:
	1. Antonius Kevin Budi Saputra – 00000045444
	2. Vanness Iwata – 00000046190
	3. Vallencius Gavriel Alfredo Siswanto – 00000045651
	4. Filbert Mangiri – 00000050612
	5. Reynard Matthew Yaputra  – 00000043407
	6. Bonifasius Ariesto Adrian Finantyo – 00000042580
	7. Darren Lionardo – 00000044057

Link github proyek Ionic-React: https://github.com/antoniuskevin15/TiKet
Link github proyek API: https://github.com/antoniuskevin15/tiket-api

Link drive semua proyek: https://drive.google.com/drive/folders/1WqMZ3KXWkZ_Sqj8htNouWNfaSS2ENIiM?usp=sharing

Konfigurasi proyek:
Ketikkan npm install pada terminal yang sudah tertuju pada proyek,
lalu ketikkan ionic serve untuk melakukan serve tampilan website.

Untuk tampilan android, cukup buka di Android Studio file Android yang
telah di-build.

Kredensial:
1. User
Email: adrianfinantyo@gmail.com
Password: adrian12345

2. Admin
Email: vallencius@gmail.com
Password: testing12345
