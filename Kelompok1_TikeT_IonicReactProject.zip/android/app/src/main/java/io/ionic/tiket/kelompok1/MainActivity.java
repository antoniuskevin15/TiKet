package io.ionic.tiket.kelompok1;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
